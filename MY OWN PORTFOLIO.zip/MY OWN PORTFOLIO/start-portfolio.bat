@echo off
setlocal

cd /d "%~dp0"
set "PORT=8001"
set "URL=http://127.0.0.1:%PORT%/"
set "PYTHON_CMD="

where python >nul 2>nul
if not errorlevel 1 (
    set "PYTHON_CMD=python"
) else (
    where py >nul 2>nul
    if not errorlevel 1 (
        set "PYTHON_CMD=py"
    ) else (
        echo Python is unavailable. Opening the portfolio directly...
        start "" "%~dp0index.html"
        exit /b 0
    )
)

echo Starting local portfolio server on %URL%
start "" cmd /c "%PYTHON_CMD% -m http.server %PORT% --bind 127.0.0.1"

for /L %%I in (1,1,25) do (
    powershell -NoProfile -Command "$socket = New-Object System.Net.Sockets.TcpClient; try { $socket.Connect('127.0.0.1', %PORT%); exit 0 } catch { exit 1 } finally { $socket.Dispose() }" >nul 2>&1
    if not errorlevel 1 goto open_browser
    ping 127.0.0.1 -n 2 >nul
)

echo Local server did not become ready. Opening the portfolio directly...
start "" "%~dp0index.html"
exit /b 0

:open_browser
echo Opening portfolio in your default browser...
start "" "%URL%"

endlocal
